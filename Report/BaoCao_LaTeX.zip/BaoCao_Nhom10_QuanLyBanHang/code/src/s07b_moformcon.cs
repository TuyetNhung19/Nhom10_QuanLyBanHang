private T MoFormCon<T>(bool phongToToiDa = true) where T : Form, new()
{
    T? daMo = MdiChildren.OfType<T>().FirstOrDefault();
    if (daMo != null)
    {
        if (daMo.WindowState == FormWindowState.Minimized)
        {
            daMo.WindowState = phongToToiDa ? FormWindowState.Maximized : FormWindowState.Normal;
        }

        daMo.Activate();
        return daMo;
    }

    var formMoi = new T { MdiParent = this };
    if (phongToToiDa)
    {
        formMoi.WindowState = FormWindowState.Maximized;
    }

    formMoi.Show();
    return formMoi;
}
