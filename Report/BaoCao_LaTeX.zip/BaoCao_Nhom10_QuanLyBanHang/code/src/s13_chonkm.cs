public KetQuaKhuyenMai ChonKhuyenMaiTotNhat(IReadOnlyList<ChiTietHoaDon> chiTiet, DateTime ngay,
    IEnumerable<DTO.KhuyenMai> dsKhuyenMai)
{
    if (chiTiet.Count == 0)
    {
        return new KetQuaKhuyenMai();
    }

    List<IQuyTacKhuyenMai> dsQuyTac = dsKhuyenMai
        .Where(km => km.ConHieuLuc(ngay))
        .Select(QuyTacKhuyenMaiFactory.Tao)
        .ToList();

    var tot = dsQuyTac
        .Select(qt => new { QuyTac = qt, Giam = qt.TinhGiam(chiTiet) })
        .Where(x => x.Giam > 0)
        .OrderByDescending(x => x.Giam)
        .ThenBy(x => x.QuyTac.ThongTin.MaKM)
        .FirstOrDefault();

    decimal giamHienTai = tot?.Giam ?? 0;

    string? loiNhac = dsQuyTac
        .Where(qt => qt != tot?.QuyTac)
        .Select(qt => new
        {
            LoiNhac = qt.GoiYMuaThem(chiTiet),
            TiemNang = (qt as QuyTacKhuyenMaiCoSo)?.GiamTiemNang(chiTiet) ?? 0,
            ConThieu = (qt as QuyTacKhuyenMaiCoSo)?.TiLeConThieu(chiTiet) ?? 1
        })
        .Where(x => x.LoiNhac != null && x.TiemNang > giamHienTai)
        .OrderBy(x => x.ConThieu)
        .ThenByDescending(x => x.TiemNang)
        .Select(x => x.LoiNhac)
        .FirstOrDefault();

    return new KetQuaKhuyenMai
    {
        KhuyenMaiApDung = tot?.QuyTac.ThongTin,
        TienGiam = giamHienTai,
        LoiNhac = loiNhac
    };
}
