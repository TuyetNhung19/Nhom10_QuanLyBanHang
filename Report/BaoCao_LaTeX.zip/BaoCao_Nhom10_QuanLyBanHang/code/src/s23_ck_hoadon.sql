ALTER TABLE dbo.HoaDon ADD
    CONSTRAINT FK_HoaDon_TaiKhoan  FOREIGN KEY (MaTK) REFERENCES dbo.TaiKhoan (MaTK)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT FK_HoaDon_KhachHang FOREIGN KEY (MaKH) REFERENCES dbo.KhachHang (MaKH)
        ON DELETE NO ACTION ON UPDATE NO ACTION,              -- KH-02: khách có hóa đơn không xóa được
    CONSTRAINT FK_HoaDon_KhuyenMai FOREIGN KEY (MaKM) REFERENCES dbo.KhuyenMai (MaKM)
        ON DELETE NO ACTION ON UPDATE NO ACTION,              -- KM-04: KM đã dùng không xóa được
    CONSTRAINT CK_HoaDon_MaHD          CHECK (MaHD LIKE 'HD[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
    CONSTRAINT CK_HoaDon_TrangThai     CHECK (TrangThai IN (1, 2)),
    CONSTRAINT CK_HoaDon_TamTinh       CHECK (TamTinh >= 0),
    CONSTRAINT CK_HoaDon_GiamGia       CHECK (GiamGia >= 0 AND GiamGia <= TamTinh),
    CONSTRAINT CK_HoaDon_TongThanhToan CHECK (TongThanhToan = TamTinh - GiamGia),
    CONSTRAINT CK_HoaDon_TienKhachDua  CHECK (TienKhachDua >= TongThanhToan),
    CONSTRAINT CK_HoaDon_TienThoi      CHECK (TienThoi = TienKhachDua - TongThanhToan),
    CONSTRAINT CK_HoaDon_LyDoHuy       CHECK (TrangThai = 1 OR LyDoHuy IS NOT NULL);
