[TestMethod]
public void TC17_Don151000_KhongGiam_CoLoiNhac()
{
    var chiTiet = new List<ChiTietHoaDon>
    {
        Dong("S0001", 79_000, 1, MaLoaiVanHoc),
        Dong("S0008", 72_000, 1, MaLoaiVanHoc)
    };

    KetQuaKhuyenMai kq = _bll.ChonKhuyenMaiTotNhat(chiTiet, HomNay, DanhSachMau());

    Assert.AreEqual(0m, kq.TienGiam);
    Assert.IsNull(kq.KhuyenMaiApDung);
    Assert.AreEqual("Mua thêm 49.000đ để được giảm 10%", kq.LoiNhac);
}
