public decimal TinhGiam(IReadOnlyList<ChiTietHoaDon> chiTiet)
{
    decimal tamTinh = TinhTamTinh(chiTiet);
    if (tamTinh <= 0)
    {
        return 0;
    }

    decimal giam = TinhGiamTheoQuyTac(chiTiet, tamTinh);

    // KM-03: tiền giảm không âm và không vượt tạm tính
    return Math.Clamp(giam, 0, tamTinh);
}

protected abstract decimal TinhGiamTheoQuyTac(IReadOnlyList<ChiTietHoaDon> chiTiet, decimal tamTinh);
