private void PhanQuyen()
{
    bool thuNgan = PhienDangNhap.LaThuNgan;
    bool quanLy = PhienDangNhap.LaQuanLy;
    bool admin = PhienDangNhap.LaAdmin;
    bool banHang = thuNgan || quanLy;
    // Danh mục
    mnuLoaiSach.Available = quanLy;
    mnuSach.Available = quanLy;
    mnuKhachHang.Available = banHang;
    mnuKhuyenMai.Available = quanLy;
    // Bán hàng
    mnuLapHoaDon.Available = banHang;
    mnuTraCuuHoaDon.Available = banHang;
    // Báo cáo
    mnuBangDieuKhien.Available = banHang;
    mnuThongKe.Available = quanLy;
    mnuBaoCaoCuoiNgay.Available = banHang;
    // Quản trị
    mnuTaiKhoan.Available = admin;
    // Thanh công cụ
    tsbBanHang.Available = banHang;
    tsbTraCuu.Available = banHang;
    tsbKhachHang.Available = banHang;
    tsbSach.Available = quanLy;
    tsbThongKe.Available = quanLy;
    tssDangXuat.Available = banHang;

    // Ẩn menu cha khi mọi mục con đều bị ẩn
    foreach (ToolStripMenuItem menuCha in mnuChinh.Items.OfType<ToolStripMenuItem>())
    {
        if (menuCha.DropDownItems.Count > 0 && menuCha != mnuCuaSo)
        {
            menuCha.Available = menuCha.DropDownItems.OfType<ToolStripMenuItem>().Any(muc => muc.Available);
        }
    }
}