protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
{
    switch (keyData)
    {
        case Keys.F1:
            txtTimSach.Focus();
            txtTimSach.SelectAll();
            return true;

        case Keys.F2:
            txtSDTKhach.Focus();
            txtSDTKhach.SelectAll();
            return true;

        case Keys.F4:
            nudTienKhachDua.Focus();
            nudTienKhachDua.Select(0, nudTienKhachDua.Text.Length);
            return true;

        case Keys.F8:
            TreoDonHienTai();
            return true;

        case Keys.F9:
            // TC16: lưu hóa đơn và mở xem trước bản in
            LuuHoaDon(inSauKhiLuu: true);
            return true;

        case Keys.Delete when ChoPhepPhimSuaDong():
            XoaDongDangChon();
            FocusMaSach();
            return true;

        case Keys.Add or Keys.Oemplus or (Keys.Oemplus | Keys.Shift) when ChoPhepPhimSuaDong():
            TangGiamSoLuong(+1);
            FocusMaSach();
            return true;

        case Keys.Subtract or Keys.OemMinus when ChoPhepPhimSuaDong():
            TangGiamSoLuong(-1);
            FocusMaSach();
            return true;
    }

    return base.ProcessCmdKey(ref msg, keyData);
}
