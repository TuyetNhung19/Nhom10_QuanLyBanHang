public static T Goi<T>(Func<T> hamDAL)
{
    try
    {
        return hamDAL();
    }
    catch (SqlException ex) when (LaLoiNghiepVu(ex))
    {
        throw ChuyenThanhLoiNghiepVu(ex);
    }
}

private static bool LaLoiNghiepVu(SqlException ex) =>
    ex.Number is >= 50000 and <= 50099 or 2627 or 2601 or 547;
