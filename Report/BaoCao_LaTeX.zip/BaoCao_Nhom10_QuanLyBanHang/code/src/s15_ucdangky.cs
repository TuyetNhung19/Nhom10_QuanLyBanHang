private void DangKySuKien()
{
    if (_daDangKy)
    {
        return;
    }

    HoaDonBLL.HoaDonDaLuu += HoaDon_ThayDoi;
    HoaDonBLL.HoaDonDaHuy += HoaDon_ThayDoi;
    _daDangKy = true;
}

private void HuyDangKySuKien()
{
    HoaDonBLL.HoaDonDaLuu -= HoaDon_ThayDoi;
    HoaDonBLL.HoaDonDaHuy -= HoaDon_ThayDoi;
    _daDangKy = false;
    tmrLamMoi.Stop();
}
