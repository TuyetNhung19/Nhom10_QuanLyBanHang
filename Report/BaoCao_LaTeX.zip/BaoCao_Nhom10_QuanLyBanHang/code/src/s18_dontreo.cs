public void Treo(HoaDonTam don)
{
    PhienDangNhap.YeuCauVaiTro(VaiTro.ThuNgan, VaiTro.QuanLy);
    if (don.ChiTiet.Count == 0)
    {
        throw new BusinessException("Đơn chưa có sách nào, không thể treo.");
    }
    int maTK = PhienDangNhap.MaTK;
    lock (Khoa)
    {
        List<HoaDonTam> ds = LayDanhSachCuaToi(maTK);
        if (ds.Count >= SoDonToiDa)
        {
            throw new BusinessException($"Mỗi thu ngân chỉ được treo tối đa {SoDonToiDa} đơn (BH-01).");
        }
        ds.Add(new HoaDonTam
        {
            Id = don.Id,
            MaTK = maTK,
            ThoiGianTreo = DateTime.Now,
            Khach = don.Khach,
            GhiChu = don.GhiChu,
            ChiTiet = don.ChiTiet.Select(ct => ct.SaoChep()).ToList()
        });
    }
}
