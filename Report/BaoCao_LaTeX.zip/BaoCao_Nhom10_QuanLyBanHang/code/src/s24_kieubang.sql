CREATE TYPE dbo.ChiTietHoaDonType AS TABLE
(
    MaSach  VARCHAR(20) NOT NULL PRIMARY KEY,
    SoLuong INT         NOT NULL
);
