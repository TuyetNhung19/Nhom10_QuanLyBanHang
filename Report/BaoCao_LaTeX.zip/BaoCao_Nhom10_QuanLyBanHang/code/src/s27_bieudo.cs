protected override void OnPaint(PaintEventArgs e)
{
    base.OnPaint(e);
    Ve(e.Graphics, ClientRectangle, Font, TieuDe, DonViTruc, HeSoTruc, LaTien, MauCot, _duLieu, _vungCot);
}
