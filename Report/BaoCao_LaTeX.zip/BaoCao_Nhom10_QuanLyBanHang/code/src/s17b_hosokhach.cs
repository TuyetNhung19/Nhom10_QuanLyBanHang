public HoSoKhachHang LayHoSoKhach(int maKH)
{
    PhienDangNhap.YeuCauVaiTro(VaiTro.ThuNgan, VaiTro.QuanLy);

    List<DongLichSuMua> dongMua = XuLyLoiCSDL.Goi(() => _khachHangDal.LayDongLichSuMua(maKH));
    List<HoaDon> hoaDon = XuLyLoiCSDL.Goi(() => _khachHangDal.LayLichSuHoaDon(maKH));

    return new HoSoKhachHang
    {
        MaKH = maKH,
        SoLanMua = dongMua.Select(d => d.MaHD).Distinct().Count(),
        TongChiTieu = hoaDon.Where(hd => hd.TrangThai == TrangThaiHoaDon.HoanTat).Sum(hd => hd.TongThanhToan),
        LanMuaGanNhat = dongMua.Count == 0 ? null : dongMua.Max(d => d.NgayLap),
        LoaiHayMua = dongMua
            .GroupBy(d => d.TenLoai)
            .OrderByDescending(nhom => nhom.Sum(d => d.SoLuong))
            .ThenBy(nhom => nhom.Key)
            .Take(3)
            .Select(nhom => nhom.Key)
            .ToList()
    };
}
