public interface IKhachHangView
{
    int? MaKHDangChon { get; }
    string HoTen { get; set; }
    string SDT { get; set; }
    string Email { get; set; }
    string DiaChi { get; set; }
    string TuKhoa { get; set; }
    void CaiDatManHinh(bool choPhepXoa, bool cheDoChon);
    void HienDanhSach(List<KhachHang> danhSach, int? maKHChon);
    void HienLichSu(List<HoaDon>? lichSu, string tongKet);
    void HienThongBao(string thongDiep);
    void HienLoi(string? truong, string thongDiep);
    bool XacNhan(string thongDiep);
    void XoaONhap();
    void DatCheDo(bool dangNhap, bool coKhachDangChon);
    void DongVaTraVe(KhachHang? khach);
}
