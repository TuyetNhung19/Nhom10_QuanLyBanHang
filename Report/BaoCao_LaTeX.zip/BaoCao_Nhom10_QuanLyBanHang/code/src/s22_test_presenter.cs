[TestMethod]
public void Luu_LoiNghiepVu_GanLoiVaoDungO_VaGiuCheDoNhap()
{
    _bll.LoiKhiLuu = new BusinessException("Số điện thoại 0901234567 đã thuộc khách hàng khác.", nameof(KhachHang.SDT));
    var presenter = new KhachHangPresenter(_view, null, false, _bll);
    presenter.KhoiTao();
    presenter.Them();

    presenter.Luu();

    Assert.AreEqual("SDT", _view.TruongLoi, "View gắn ErrorProvider vào ô txtSDT");
    Assert.IsTrue(_view.DangNhap, "Lỗi thì vẫn ở chế độ nhập để người dùng sửa");
    Assert.IsNull(_view.ThongBaoCuoi);
}
