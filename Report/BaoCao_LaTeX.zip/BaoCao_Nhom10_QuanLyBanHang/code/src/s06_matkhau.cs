public static class MatKhauHelper
{
    public const int DoDaiToiThieu = 6;

    public static string Bam(string matKhau)
    {
        ArgumentNullException.ThrowIfNull(matKhau);
        return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(matKhau)));
    }
}
