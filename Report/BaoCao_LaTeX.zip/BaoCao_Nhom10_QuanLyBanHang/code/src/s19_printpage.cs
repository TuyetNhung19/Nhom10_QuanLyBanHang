private void TaiLieu_PrintPage(object? sender, PrintPageEventArgs e)
{
    if (e.Graphics == null)
    {
        return;
    }
    Graphics g = e.Graphics;
    RectangleF vung = e.MarginBounds;
    float y = vung.Top;
    while (_mucTiepTheo < _dsMuc.Count)
    {
        MucIn muc = _dsMuc[_mucTiepTheo];
        float cao = muc.DoCao(g, vung.Width, this);
        // Mục đầu tiên của trang luôn được vẽ để tránh lặp vô hạn khi một mục cao hơn cả trang
        if (y + cao > vung.Bottom && y > vung.Top)
        {
            e.HasMorePages = true;
            return;
        }
        muc.Ve(g, vung.Left, y, vung.Width, this);
        y += cao;
        _mucTiepTheo++;
    }
    e.HasMorePages = false;
}
