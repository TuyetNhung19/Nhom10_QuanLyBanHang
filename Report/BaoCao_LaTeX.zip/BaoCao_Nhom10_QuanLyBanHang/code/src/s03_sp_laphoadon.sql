SET XACT_ABORT ON;   -- mọi lỗi (kể cả mất kết nối/timeout) đều hủy toàn bộ transaction
BEGIN TRY
    BEGIN TRANSACTION;
    -- 1. Tài khoản phải tồn tại, đang hoạt động, là Thu ngân hoặc Quản lý (TK-01, phân quyền)
    -- 2. Hóa đơn phải có ít nhất 1 dòng, số lượng > 0 (HD-01)
    -- 3. Khóa các dòng sách liên quan đến hết transaction để không ai bán chen (HD-02)
    INSERT INTO @Sach (MaSach, TenSach, MaLoai, GiaBan, SoLuongTon, TrangThai, SoLuong)
    SELECT ct.MaSach, s.TenSach, s.MaLoai, s.GiaBan, s.SoLuongTon, s.TrangThai, ct.SoLuong
    FROM @ChiTiet AS ct
    LEFT JOIN dbo.Sach AS s WITH (UPDLOCK, HOLDLOCK, ROWLOCK) ON s.MaSach = ct.MaSach;
    -- 4. Đơn giá lấy từ Sach.GiaBan tại thời điểm lưu (HD-04); so với tạm tính trên Form
    -- 5. Khuyến mãi (KM-01, KM-02, KM-03)
    -- 6. Thanh toán (HD-03)
    -- 7. Sinh mã hóa đơn bên trong transaction (HD-07)
    EXEC dbo.sp_TaoMaHoaDon @Ngay = @Ngay, @MaHD = @MaHD OUTPUT;
    -- 8. Ghi dữ liệu (HD-05)
    INSERT INTO dbo.HoaDon (MaHD, NgayLap, MaTK, MaKH, TamTinh, GiamGia, MaKM,
                            TongThanhToan, TienKhachDua, TienThoi, TrangThai, LyDoHuy, GhiChu)
    VALUES (@MaHD, @Now, @MaTK, @MaKH, @TamTinh, @GiamGia, @MaKM,
            @TongThanhToan, @TienKhachDua, @TienThoi, 1, NULL,
            NULLIF(LTRIM(RTRIM(@GhiChu)), N''));
    INSERT INTO dbo.ChiTietHoaDon (MaHD, MaSach, SoLuong, DonGia, ThanhTien)
    SELECT @MaHD, x.MaSach, x.SoLuong, x.GiaBan, x.GiaBan * x.SoLuong
    FROM @Sach AS x;
    UPDATE s
    SET s.SoLuongTon = s.SoLuongTon - x.SoLuong
    FROM dbo.Sach AS s
    INNER JOIN @Sach AS x ON x.MaSach = s.MaSach;
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
    SET @MaHD = NULL;
    THROW;
END CATCH;
