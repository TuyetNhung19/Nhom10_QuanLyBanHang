public string LapHoaDon(HoaDon hd)
{
    // Table-valued parameter: 2 cột đúng thứ tự của dbo.ChiTietHoaDonType.
    // Gộp các dòng trùng mã sách vì kiểu bảng có khóa chính MaSach.
    var bangChiTiet = new DataTable();
    bangChiTiet.Columns.Add("MaSach", typeof(string));
    bangChiTiet.Columns.Add("SoLuong", typeof(int));
    foreach (var nhom in hd.ChiTiet.GroupBy(ct => ct.MaSach))
    {
        bangChiTiet.Rows.Add(nhom.Key, nhom.Sum(ct => ct.SoLuong));
    }
    SqlParameter maHD = Database.TaoThamSoOutput("@MaHD", SqlDbType.VarChar, 20);
    Database.ExecuteNonQuery("sp_LapHoaDon", CommandType.StoredProcedure,
        Database.TaoThamSo("@MaTK", SqlDbType.Int, hd.MaTK),
        Database.TaoThamSo("@MaKH", SqlDbType.Int, hd.MaKH),
        Database.TaoThamSo("@MaKM", SqlDbType.Int, hd.MaKM),
        Database.TaoThamSo("@GiamGia", SqlDbType.Decimal, hd.GiamGia),
        Database.TaoThamSo("@TamTinhDuKien", SqlDbType.Decimal, hd.TamTinh),
        Database.TaoThamSo("@TienKhachDua", SqlDbType.Decimal, hd.TienKhachDua),
        Database.TaoThamSo("@GhiChu", SqlDbType.NVarChar, string.IsNullOrWhiteSpace(hd.GhiChu) ? null : hd.GhiChu, 255),
        Database.TaoThamSoBang("@ChiTiet", KieuBangChiTiet, bangChiTiet),
        maHD);
    return Convert.ToString(maHD.Value) ?? string.Empty;
}
