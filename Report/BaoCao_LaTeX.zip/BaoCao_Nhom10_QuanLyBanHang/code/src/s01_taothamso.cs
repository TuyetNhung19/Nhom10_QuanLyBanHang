public static SqlParameter TaoThamSo(string ten, SqlDbType kieu, object? giaTri, int size = 0)
{
    var thamSo = new SqlParameter(ChuanHoaTen(ten), kieu)
    {
        Value = giaTri ?? DBNull.Value
    };

    if (size != 0)
    {
        thamSo.Size = size;
    }

    if (kieu == SqlDbType.Decimal)
    {
        thamSo.Precision = 18;
        thamSo.Scale = 0;
    }

    return thamSo;
}
