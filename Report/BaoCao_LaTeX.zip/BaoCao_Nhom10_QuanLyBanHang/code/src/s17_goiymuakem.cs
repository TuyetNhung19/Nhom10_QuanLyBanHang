public List<GoiYSach> GoiYMuaKem(string maSach, IEnumerable<string> maDaCoTrongDon)
{
    PhienDangNhap.YeuCauVaiTro(VaiTro.ThuNgan, VaiTro.QuanLy);

    var boQua = new HashSet<string>(maDaCoTrongDon, StringComparer.OrdinalIgnoreCase) { maSach };
    List<ChiTietHoaDon> dong = XuLyLoiCSDL.Goi(() => _hoaDonDal.LayDongCuaHoaDonCoSach(maSach));

    return dong
        .Where(ct => !boQua.Contains(ct.MaSach) && ct.SoLuongTon > 0 && ct.SachDangBan)
        .GroupBy(ct => ct.MaSach)
        .OrderByDescending(nhom => nhom.Count())
        .ThenBy(nhom => nhom.First().TenSach)
        .Take(SoGoiYToiDa)
        .Select(nhom => new GoiYSach
        {
            MaSach = nhom.Key,
            TenSach = nhom.First().TenSach,
            GiaBan = nhom.First().DonGia,
            SoLuongTon = nhom.First().SoLuongTon,
            SoLanMuaCung = nhom.Count()
        })
        .ToList();
}
