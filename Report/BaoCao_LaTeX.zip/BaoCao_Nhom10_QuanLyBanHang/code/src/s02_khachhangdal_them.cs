public int Them(KhachHang kh)
{
    const string sql = @"INSERT INTO dbo.KhachHang (HoTen, SDT, Email, DiaChi)
                         OUTPUT INSERTED.MaKH
                         VALUES (@HoTen, @SDT, @Email, @DiaChi)";
    object? kq = Database.ExecuteScalar(sql, CommandType.Text,
        Database.TaoThamSo("@HoTen", SqlDbType.NVarChar, kh.HoTen, 100),
        Database.TaoThamSo("@SDT", SqlDbType.VarChar, kh.SDT, 15),
        Database.TaoThamSo("@Email", SqlDbType.VarChar, string.IsNullOrWhiteSpace(kh.Email) ? null : kh.Email, 100),
        Database.TaoThamSo("@DiaChi", SqlDbType.NVarChar, string.IsNullOrWhiteSpace(kh.DiaChi) ? null : kh.DiaChi, 255));
    return Convert.ToInt32(kq);
}
