public static void YeuCauVaiTro(params VaiTro[] vaiTroChoPhep)
{
    YeuCauDangNhap();
    if (!vaiTroChoPhep.Contains(TaiKhoanHienTai!.VaiTro))
    {
        throw new BusinessException("Bạn không có quyền thực hiện chức năng này.");
    }
}
