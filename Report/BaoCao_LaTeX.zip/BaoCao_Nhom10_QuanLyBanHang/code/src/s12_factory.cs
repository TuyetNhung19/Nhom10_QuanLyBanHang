public static class QuyTacKhuyenMaiFactory
{
    public static IQuyTacKhuyenMai Tao(DTO.KhuyenMai km) => km.LoaiKM switch
    {
        LoaiKhuyenMai.TheoTongDon => new KMTheoTongDon(km),
        LoaiKhuyenMai.TheoLoaiSach => new KMTheoLoaiSach(km),
        LoaiKhuyenMai.TheoSoLuong => new KMTheoSoLuong(km),
        _ => throw new ArgumentOutOfRangeException(nameof(km), $"Loại khuyến mãi không hợp lệ: {km.LoaiKM}")
    };
}
