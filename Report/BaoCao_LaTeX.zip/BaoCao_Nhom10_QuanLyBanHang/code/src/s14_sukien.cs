public static event EventHandler<HoaDonEventArgs>? HoaDonDaLuu;
public static event EventHandler<HoaDonEventArgs>? HoaDonDaHuy;

PhatSuKien(HoaDonDaLuu, new HoaDonEventArgs(maHD, hd.MaTK, hd.TongThanhToan));

private void PhatSuKien(EventHandler<HoaDonEventArgs>? suKien, HoaDonEventArgs e)
{
    if (suKien == null)
    {
        return;
    }
    foreach (EventHandler<HoaDonEventArgs> xuLy in suKien.GetInvocationList().Cast<EventHandler<HoaDonEventArgs>>())
    {
        try
        {
            xuLy(this, e);
        }
        catch (Exception)
        {
            // Bỏ qua: nơi nhận tự chịu trách nhiệm hiển thị lỗi của mình.
        }
    }
}
