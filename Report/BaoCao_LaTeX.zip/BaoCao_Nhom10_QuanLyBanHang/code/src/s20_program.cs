private static void Main()
{
    // Bắt lỗi chưa xử lý: phải đăng ký trước khi tạo bất kỳ Form nào
    Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
    Application.ThreadException += Application_ThreadException;
    AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

    // Font Segoe UI 10, DPI, visual styles: cấu hình trong file .csproj
    ApplicationConfiguration.Initialize();

    // Bảng màu chung cho menu/thanh công cụ/thanh trạng thái (Helpers/GiaoDien.cs)
    Helpers.GiaoDien.KhoiTao();

    // Kiểm tra kết nối CSDL trước khi vào chương trình
    if (!HeThongBLL.KiemTraKetNoi(out string loi))
    {
        MessageBox.Show(
            "Không kết nối được CSDL.\n\n" + loi +
            "\n\nCách khắc phục:\n" +
            "1. Mở Services (services.msc), bật dịch vụ SQL Server.\n" +
            "2. Kiểm tra mục Server=... trong App.config cho đúng tên máy chủ.\n" +
            "3. Đảm bảo đã chạy Database/01_TaoCSDL.sql và 02_NapDuLieuMau.sql.",
            TieuDe + " – Lỗi kết nối",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
        return;
    }
}
