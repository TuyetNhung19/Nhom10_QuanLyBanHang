public interface IQuyTacKhuyenMai
{
    DTO.KhuyenMai ThongTin { get; }
    decimal TinhGiam(IReadOnlyList<ChiTietHoaDon> chiTiet);
    string? GoiYMuaThem(IReadOnlyList<ChiTietHoaDon> chiTiet);
}
