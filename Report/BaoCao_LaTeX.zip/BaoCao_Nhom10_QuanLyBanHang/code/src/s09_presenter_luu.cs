public void Luu()
{
    var kh = new KhachHang
    {
        MaKH = _cheDo == CheDo.Sua ? KhachDangChon()?.MaKH ?? 0 : 0,
        HoTen = _view.HoTen,
        SDT = _view.SDT,
        Email = _view.Email,
        DiaChi = _view.DiaChi
    };
    try
    {
        if (_cheDo == CheDo.Them)
        {
            _bll.Them(kh);
        }
        else
        {
            _bll.Sua(kh);
        }

        if (_cheDoChon && _cheDo == CheDo.Them)
        {
            _view.DongVaTraVe(kh);
            return;
        }

        _view.HienThongBao(_cheDo == CheDo.Them ? $"Đã thêm khách hàng \"{kh.HoTen}\"." : "Đã cập nhật khách hàng.");
        DatCheDo(CheDo.Xem);
        TaiDanhSach(kh.MaKH);
    }
    catch (Exception ex)
    {
        XuLyLoi(ex);
    }
}
