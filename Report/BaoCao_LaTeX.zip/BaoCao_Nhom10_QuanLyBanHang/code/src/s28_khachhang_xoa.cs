public virtual void Xoa(int maKH)
{
    PhienDangNhap.YeuCauVaiTro(VaiTro.QuanLy);

    if (XuLyLoiCSDL.Goi(() => _dal.DaCoHoaDon(maKH)))
    {
        throw new BusinessException("Không thể xóa khách hàng đã có hóa đơn (KH-02).");
    }

    if (!XuLyLoiCSDL.Goi(() => _dal.Xoa(maKH)))
    {
        throw new BusinessException("Không tìm thấy khách hàng cần xóa.");
    }
}
