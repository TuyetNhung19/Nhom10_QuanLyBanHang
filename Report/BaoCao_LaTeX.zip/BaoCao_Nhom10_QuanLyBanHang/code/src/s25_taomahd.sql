CREATE PROCEDURE dbo.sp_TaoMaHoaDon
    @Ngay DATE = NULL,
    @MaHD VARCHAR(20) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF @Ngay IS NULL SET @Ngay = CAST(GETDATE() AS DATE);

    DECLARE @TienTo VARCHAR(10) = 'HD' + CONVERT(CHAR(8), @Ngay, 112);   -- 112 = yyyyMMdd
    DECLARE @SoCuoi INT;

    SELECT @SoCuoi = MAX(CAST(RIGHT(hd.MaHD, 3) AS INT))
    FROM dbo.HoaDon AS hd WITH (UPDLOCK, HOLDLOCK)
    WHERE hd.MaHD LIKE @TienTo + '[0-9][0-9][0-9]';

    SET @SoCuoi = ISNULL(@SoCuoi, 0) + 1;

    IF @SoCuoi > 999
        THROW 50008, N'Đã hết số thứ tự hóa đơn trong ngày (tối đa 999 hóa đơn/ngày).', 1;

    SET @MaHD = @TienTo + RIGHT('000' + CAST(@SoCuoi AS VARCHAR(10)), 3);
END
