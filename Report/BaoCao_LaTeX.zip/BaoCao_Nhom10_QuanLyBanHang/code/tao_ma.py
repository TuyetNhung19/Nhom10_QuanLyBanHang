"""
Sinh các file code/<ten>.tex (đã tô màu cú pháp) từ code/src/<ten>.cs|.sql bằng Pygments.

Vì sao không dùng gói listings: listings không xử lý được ký tự tiếng Việt có dấu
(mã Unicode > 255) khi biên dịch bằng XeLaTeX – chữ bị đảo vị trí. Các file .tex sinh ra
chỉ cần gói fancyvrb/fvextra nên biên dịch được ở mọi nơi, KHÔNG cần -shell-escape.

Cách dùng (chỉ khi sửa/thêm đoạn mã trong code/src):
    pip install pygments
    python code/tao_ma.py
"""
from pathlib import Path

from pygments import highlight
from pygments.formatters import LatexFormatter
from pygments.lexers import CSharpLexer, TransactSqlLexer
from pygments.style import Style
from pygments.token import (Comment, Keyword, Name, Number, Operator, String,
                            Token)


class KieuBaoCao(Style):
    """Bảng màu khớp với màu chung của báo cáo (preamble.tex)."""
    styles = {
        Token: "#1F2933",
        Comment: "#1E8449",
        Keyword: "bold #1B3A6B",
        Keyword.Type: "bold #2E6DB4",
        Name.Class: "#7D3C98",
        Name.Function: "#1F2933",
        String: "#C0392B",
        Number: "#AF601A",
        Operator: "#1F2933",
    }


GOC = Path(__file__).resolve().parent
NGUON = GOC / "src"

fmt = LatexFormatter(style=KieuBaoCao, commandprefix="PY")


def main() -> None:
    for tep in sorted(NGUON.iterdir()):
        if tep.suffix == ".cs":
            lexer = CSharpLexer()
        elif tep.suffix == ".sql":
            lexer = TransactSqlLexer()
        else:
            continue
        ma = tep.read_text(encoding="utf-8")
        tex = highlight(ma, lexer, fmt)
        # Bỏ \begin{Verbatim}...\end{Verbatim} mặc định để preamble tự đặt tùy chọn (số dòng, ngắt dòng)
        dong = tex.strip().splitlines()
        than = "\n".join(dong[1:-1])
        (GOC / f"{tep.stem}.tex").write_text(
            "\\begin{MaVerbatim}\n" + than + "\n\\end{MaVerbatim}\n", encoding="utf-8")
        print("Đã sinh", tep.stem + ".tex")
    (GOC / "pygments_kieu.tex").write_text(fmt.get_style_defs(), encoding="utf-8")
    print("Đã sinh pygments_kieu.tex")


if __name__ == "__main__":
    main()
